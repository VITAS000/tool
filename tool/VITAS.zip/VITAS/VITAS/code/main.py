import time
import os
import sys
import argparse
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import Step2_1_NLPAnalysis as nlp_als
import Step2_2_TF_IDF as tf_idf
import Step3_Communication as commu
import Step3_2_GetAns as get_ans

CONFIG_PATH = '../config/config.ini'

def getArgs():
    parser = argparse.ArgumentParser()
    parser.add_argument("-e", help = "input the name of an excel file in the skill_data_set_2021 directory", dest = "excel_name", type = str, default = "business_and_finance.xlsx")
    parser.add_argument("-l", help = "input the path to save logs", dest = "log_path", type = str, default = "../business/")
    parser.add_argument("-o", help = "input the path to save results", dest = "res_path", type = str, default = "../result/")
    parser.add_argument("-c", help = "use chatbot", dest = "chat_bot", action = 'store_true')
    parser.add_argument("-nc", help = "not use chatbot", dest = "chat_bot", action = 'store_false')
    parser.set_defaults(chat_bot=False)
    args = parser.parse_args()
    EXCEL_PATH = "../skill_data_set_2021/" + args.excel_name
    LOG_PATH = args.log_path
    if LOG_PATH[-1] != '/':
        LOG_PATH = LOG_PATH + '/'
    RESULT_PATH = args.res_path
    if RESULT_PATH[-1] != '/':
        RESULT_PATH = RESULT_PATH + '/'
    CHATBOT = args.chat_bot
    return EXCEL_PATH, LOG_PATH, RESULT_PATH, CHATBOT

def open_misuku(chatbot):
    chrome_options = Options()
    if chatbot == True:
        driver = webdriver.Chrome(options= chrome_options, executable_path=commu.CHROME_PATH)
        driver.get('https://chat.kuki.ai/')
        time.sleep(5)
        driver.find_element_by_xpath(get_ans.PATH_DIC['justchat']).click()
        time.sleep(1)
        driver.find_element_by_xpath(get_ans.PATH_DIC['accept']).click()
        time.sleep(2)
    else:
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--headless')
        driver = webdriver.Chrome(options= chrome_options, executable_path=commu.CHROME_PATH)
    return driver

def close_driver(driver):
    driver.close()
    driver.quit()

def init_dir(LOG_PATH, RESULT_PATH):
    if not os.path.exists(RESULT_PATH):
        os.makedirs(RESULT_PATH)
    if not os.path.exists('../cookie'):
        os.makedirs("../cookie/")
    if not os.path.exists(LOG_PATH):
        os.makedirs(LOG_PATH)


if __name__ == '__main__':
    EXCEL_PATH, LOG_PATH, RESULT_PATH, CHATBOT = getArgs()
    if not os.path.exists(EXCEL_PATH):
        print("the excel path does not exist")
        sys.exit()
    print(EXCEL_PATH, LOG_PATH, RESULT_PATH, CHATBOT)
    init_dir(LOG_PATH, RESULT_PATH)
    driver = open_misuku(CHATBOT)
    spider = commu.Spider(CONFIG_PATH)
    spider.open_log_page()
    index = 1
    while True:
        skill = nlp_als.Skill(EXCEL_PATH, index)
        if skill.skillName == '<end_of_excel>':
            break
        if skill.skillName != '':
            tfidf = tf_idf.TF_IDF()
            skillFuncs = tfidf.getSkillFunctions(EXCEL_PATH, index)
            commu.generateTest(LOG_PATH, RESULT_PATH, spider, skill, skillFuncs, driver)
            spider.web_driver.refresh()
            time.sleep(15)
            deviceLevel_element = spider.web_driver.find_element_by_id('deviceLevel-label')
            spider.web_driver.execute_script("arguments[0].click();", deviceLevel_element)
        index = index + 1
    close_driver(driver)
    close_driver(spider.web_driver)
