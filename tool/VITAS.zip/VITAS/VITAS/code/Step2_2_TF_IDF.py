import os
import nltk
import math
import string
import openpyxl
from nltk.corpus import stopwords
from collections import Counter
from nltk.stem.porter import *
import Step2_1_NLPAnalysis as nlp_als

CORPUS_DIR = "../corpus"

def get_count(text):
    tokens = get_tokens(text)
    filtered = [w for w in tokens if not w in stopwords.words('english')]
    stemmer = PorterStemmer()
    stemmed = stem_tokens(filtered, stemmer)
    #print(stemmed)
    count = Counter(stemmed)
    return count

def get_tokens(text):
    lowers = text.lower()
    #remove the punctuation using the character deletion step of translate
    remove_punctuation_map = dict((ord(char), None) for char in string.punctuation)
    no_punctuation = lowers.translate(remove_punctuation_map)
    tokens = nltk.word_tokenize(no_punctuation)
    return tokens

def stem_tokens(tokens, stemmer):
    stemmed = []
    for item in tokens:
        stemmed.append(stemmer.stem(item))
    return stemmed

class TF_IDF:
    def __init__(self):
        self.count_list = []
        self.wordNum = 5
        self.files = os.listdir(CORPUS_DIR)
        for filename in self.files:
            file = open(CORPUS_DIR + "/" + filename, "r")
            text = ''
            #print(filename)
            line = file.readline()
            while(line):
                text += line
                line = file.readline()
            count = get_count(text)
            self.count_list.append(count)
            file.close()
    
    '''def getSkillFunctions(self, description):
        self.skillFuncs = []
        count = get_count(description)
        self.count_list.append(count)
        scores = {word: self.tfidf(word, count) for word in count}
        sorted_words = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        for word, score in sorted_words[:self.wordNum]:
            self.skillFuncs.append(word)
        self.count_list.pop()
        return self.skillFuncs'''

    def getSkillFunctions(self, excel_file_name, line):
        self.skillFuncs = []
        inCorpus = False
        excel = openpyxl.load_workbook(excel_file_name)
        sheet = excel.worksheets[0]
        skillAttri = list(sheet.rows)[line]
        title = str(skillAttri[0].value)
        fileName = re.sub(r'(\W+)', '_', title) + '.txt'
        if fileName not in self.files:
            text = str(skillAttri[4].value)
            text = nlp_als.toValidStr(text)
            count = get_count(text)
            self.count_list.append(count)
        else:
            index = self.files.index(fileName)
            count = self.count_list[index]
            inCorpus = True
        scores = {word: self.tfidf(word, count) for word in count}
        sorted_words = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        for word, score in sorted_words[:self.wordNum]:
            self.skillFuncs.append(word)
        if inCorpus == False:
            self.count_list.pop()
        return self.skillFuncs

    def tf(self, word, count):
        return count[word] / sum(count.values())
 
    def n_containing(self, word):
        return sum(1 for count in self.count_list if word in count)
 
    def idf(self, word):
        return math.log(len(self.count_list) / (1 + self.n_containing(word)))
 
    def tfidf(self, word, count):
        return self.tf(word, count) * self.idf(word)