import os
from selenium import webdriver
import selenium.common
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import pickle
import time
import re
import sys
import poplib
import configparser
from email.parser import Parser
import Step2_1_NLPAnalysis as nlp_als
import Step3_1_InputAndResponse as in_a_re
import Step3_2_GetAns as get_ans
import Step3_3_ProblemDetection as pro_detc

LOGOUT_URL = "https://www.amazon.com/ap/signin?_encoding=UTF8&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fie%3DUTF8%26action%3Dsign-out%26path%3D%252Fgp%252Fyourstore%252Fhome%26ref_%3Dnav_AccountFlyout_signout%26signIn%3D1%26useRedirectOnSuccess%3D1"
CHROME_PATH = "../chrome/chromedriver"
COOKIE_DIR = "../cookie/console_cookie7.pkl"

class Spider:
    def __init__(self, config_path):
        chrome_options = Options()
        '''chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--headless')'''
        self.web_driver = webdriver.Chrome(options= chrome_options, executable_path=CHROME_PATH)
        cf = configparser.ConfigParser()
        cf.read(config_path)
        secs = cf.sections()
        self.password = cf.get('Amazon', 'password')
        self.username = cf.get('Amazon', 'username')
        self.url = cf.get('Amazon', 'console')
        self.emailpass = cf.get('Email', 'token')
        self.popserver = cf.get('Email', 'popserver')
        self.home_page = 'https://www.amazon.com/'
        self.log_out_page = 'https://developer.amazon.com/alexa/console/logout?language=en_US/'
        if not os.path.exists(COOKIE_DIR):
            self.generate_cookie()
        cookie_file = open(COOKIE_DIR, 'rb')
        self.cookie_list = pickle.load(cookie_file)
        cookie_file.close()
        print("open amazon")

    def deal_with_cookie_wrong(self):
        self.web_driver.get(self.log_out_page)
        time.sleep(1)
        self.web_driver.get('https://developer.amazon.com/alexa/console/ask')
        time.sleep(2)
        no_pass = False
        no_email = False
        time_tmp = time.time()
        while time.time() - time_tmp < 1*60 and self.web_driver.current_url != self.url and (no_pass == False or no_email == False):
            try:
                email = self.web_driver.find_element_by_id('ap_email')
                email.send_keys(self.username)
                time.sleep(1)
                no_email = False
            except:
                no_email = True
            try:
                passw = self.web_driver.find_element_by_id('ap_password')
                passw.send_keys(self.password)
                passw.send_keys(Keys.ENTER)
                time.sleep(15)
                no_pass = False
            except:
                no_pass = True
        self.web_driver.get(self.url)
        time.sleep(15)
        if self.web_driver.current_url != self.url:
            print(self.web_driver.current_url)
            print("open console error!")
            sys.exit()
        deviceLevel_element = self.web_driver.find_element_by_id('deviceLevel-label')
        self.web_driver.execute_script("arguments[0].click()", deviceLevel_element)
        time.sleep(1)
        
    def refresh(self):
        self.web_driver.get(self.home_page)
        self.judge_curUrl()
        time.sleep(15)
        # 打开 log 窗口
        self.web_driver.find_element_by_id('deviceLevel-label').click()
        deviceLevel_element = self.web_driver.find_element_by_id('deviceLevel-label')
        self.web_driver.execute_script("arguments[0].click();", deviceLevel_element)
        time.sleep(1)

    def load_cookie(self):
        for cookie in self.cookie_list:
            self.web_driver.add_cookie(cookie)
        time.sleep(2)
        self.web_driver.refresh()
        time.sleep(3)

    def dump_cookie(self, cookie_dir, webdriver):
        new_cookies = webdriver.get_cookies()
        cookie1 = {}
        cookie2 = {}
        cookie3 = {}
        cookie4 = {}
        #cookies = {}
        for cookie_tmp in new_cookies:
            if cookie_tmp['name'] == 'ubid-main':
                cookie1['name'] = cookie_tmp['name']
                cookie1['value'] = cookie_tmp['value']
            elif cookie_tmp['name'] == 'x-main':
                cookie2['name'] = cookie_tmp['name']
                cookie2['value'] = cookie_tmp['value']
            elif cookie_tmp['name'] == 'at-main':
                cookie3['name'] = cookie_tmp['name']
                cookie3['value'] = cookie_tmp['value']
            elif cookie_tmp['name'] == 'sess-at-main':
                cookie4['name'] = cookie_tmp['name']
                cookie4['value'] = cookie_tmp['value']
            #cookies[cookie_tmp['name']] = cookie_tmp['value']
        new_cookies = [cookie1, cookie2, cookie3, cookie4]
        cookie_file = open(cookie_dir, 'wb')
        pickle.dump(new_cookies, cookie_file)
        #pickle.dump(cookies, cookie_file)
        cookie_file.close()

    def auto_login_bak(self):
        try:
            # self.web_driver.get(self.home_page)
            log_in_button = self.web_driver.find_element_by_xpath('//*[@id="nav-link-accountList"]')
            self.web_driver.execute_script("arguments[0].click()", log_in_button)
            self.load_cookie()
            self.web_driver.find_element_by_id('ap_password').send_keys(self.password)
            self.web_driver.find_element_by_id('ap_password').send_keys(Keys.ENTER)
            # self.web_driver.find_element_by_class_name('a-button-input').click()
        except selenium.common.exceptions.NoSuchElementException:
            return

    def auto_login(self):
        try:
            self.web_driver.find_element_by_id('ap_password').send_keys(self.password)
            self.web_driver.find_element_by_id('ap_password').send_keys(Keys.ENTER)
        except selenium.common.exceptions.NoSuchElementException:
            return

    def auto_login_2(self):
        try:
            self.web_driver.find_element_by_id('ap_email').send_keys(self.username)
            self.web_driver.find_element_by_id('ap_email').send_keys(Keys.ENTER)
            time.sleep(5)
            self.web_driver.find_element_by_id('ap_password').send_keys(self.password)
            # 记住登录
            rem = self.web_driver.find_element_by_xpath(
                '//*[@id="authportal-main-section"]/div[2]/div/div/div/form/div/div[2]/div/div/label/div/label/input')
            self.web_driver.execute_script("arguments[0].click()", rem)
            self.web_driver.find_element_by_id('ap_password').send_keys(Keys.ENTER)
            # self.web_driver
            # self.web_driver.find_element_by_class_name('a-button-input').click()
        except selenium.common.exceptions.NoSuchElementException:
            return

    def judge_curUrl(self):
        if self.web_driver.current_url != self.home_page:
            self.web_driver.get(self.home_page)
        # 加载 cookie 并刷新页面
        time_tmp = time.time()
        while time.time() - time_tmp < 1*60:
            try:
                self.load_cookie()
                break
            except selenium.common.exceptions.InvalidCookieDomainException:
                self.web_driver.get(self.home_page)
                self.web_driver.refresh()
                time.sleep(3)
        time.sleep(3)
        # 跳转console页面
        #print(self.url)
        self.web_driver.get(self.url)
        time.sleep(15)
        if self.web_driver.current_url == self.url:
            return
        no_pass = False
        no_email = False
        while self.web_driver.current_url != self.url and (no_pass == False or no_email == False):
            try:
                email = self.web_driver.find_element_by_id('ap_email')
                email.send_keys(self.username)
                time.sleep(1)
                no_email = False
            except:
                no_email = True
            try:
                passw = self.web_driver.find_element_by_id('ap_password')
                passw.send_keys(self.password)
                passw.send_keys(Keys.ENTER)
                time.sleep(15)
                no_pass = False
            except:
                no_pass = True
        return

    def open_log_page(self):
        self.judge_curUrl()
        # 打开 log 窗口
        # spider.web_driver.find_element_by_id('deviceLevel-label').click()
        if self.web_driver.current_url != self.url:
            print(self.web_driver.current_url)
            print("open console error!")
            sys.exit()
        time.sleep(5)
        deviceLevel_element = self.web_driver.find_element_by_id('deviceLevel-label')
        self.web_driver.execute_script("arguments[0].click()", deviceLevel_element)
        time.sleep(1)

    def decodeBody(self, msgPart):
        contentType = msgPart.get_content_type()  # 判断邮件内容的类型,text/html
        textContent = ""
        if contentType == 'text/plain' or contentType == 'text/html':
            content = msgPart.get_payload(decode=True)
            charset = msgPart.get_charset()
            if charset is None:
                contentType = msgPart.get('Content-Type', '').lower()
                position = contentType.find('charset=')
                if position >= 0:
                    charset = contentType[position + 8:].strip()
            if charset:
                textContent = content.decode(charset)
        return textContent

    def get_link(self):
        """ 创建POP3对象，添加用户名和密码"""
        pop3Server = poplib.POP3(self.popserver)
        pop3Server.user(self.username)
        pop3Server.pass_(self.emailpass)

        messageCount, mailboxSize = pop3Server.stat()
        """ 获取任意一封邮件的邮件对象【第一封邮件的编号为1，而不是0】"""
        msgIndex = messageCount
        # 获取第msgIndex封邮件的信息
        response, msgLines, octets = pop3Server.retr(msgIndex)
        # msgLines中为该邮件的每行数据,先将内容连接成字符串，再转化为email.message.Message对象
        msgLinesToStr = b"\r\n".join(msgLines).decode("utf8", "ignore")
        messageObject = Parser().parsestr(msgLinesToStr)
        msgDate = messageObject["date"]
        senderContent = messageObject["From"]

        if messageObject.is_multipart():  # 判断邮件是否由多个部分构成
            messageParts = messageObject.get_payload()  # 获取邮件附载部分
            for messagePart in messageParts:
                bodyContent = self.decodeBody(messagePart)
                if bodyContent:
                    link = re.findall(r'<a style="font-size: 12px; color: black; pointer-events: none; cursor: default; text-decoration: none; font-weight: 600">(.*?)</a>', str(bodyContent), re.S)
                    if len(link) > 0:
                        pop3Server.quit()
                        return link[0].strip()
        else:
            bodyContent = self.decodeBody(messageObject)
            if bodyContent:
                link = re.findall(r'<a style="font-size: 12px; color: black; pointer-events: none; cursor: default; text-decoration: none; font-weight: 600">(.*?)</a>', str(bodyContent), re.S)
                if len(link) > 0:
                    pop3Server.quit()
                    return link[0].strip()
        pop3Server.quit()
        return ''

    def approve(self, link):
        chrome_options = Options()
        '''chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--headless')'''
        driver = webdriver.Chrome(options= chrome_options, executable_path=CHROME_PATH)
        driver.get(link)
        time.sleep(5)
        try:
            approve_botton = driver.find_element_by_xpath('//input[@name="customerResponseApproveButton"]')
            driver.execute_script("arguments[0].click();", approve_botton)
        except:
            pass
        time.sleep(5)
        driver.close()
        driver.quit()

    def generate_email_cookie(self):
        self.email_driver.switch_to.frame(self.email_driver.find_element_by_xpath('//iframe[starts-with(@id,"x-URS")]'))
        self.email_driver.find_element_by_name('email').send_keys(self.username)
        self.email_driver.find_element_by_name('password').send_keys(self.emailpass)
        self.email_driver.find_element_by_name('un-login').click()
        time.sleep(2)
        self.email_driver.find_element_by_id('dologin').click()
        time.sleep(10)
        tmp_cookie = self.email_driver.execute_script('return document.cookie')
        new_cookie = []
        for line in tmp_cookie.split(';'):
            cookie = {}
            key,value = line.split('=',1)
            cookie['name'] = key
            cookie['value'] = value
            new_cookie.append(cookie)
        cookie_file = open(EMAIL_COOKIE_DIR, 'wb')
        pickle.dump(new_cookie, cookie_file)
        cookie_file.close()
        self.email_driver.switch_to.default_content()
        name = self.email_driver.find_element_by_id("spnUid").text
        print(name)
        if name == (self.username):
            print('登录成功')
        else:
            print('登录失败')
            sys.exit()

    def generate_cookie(self):  # 生成cookie_console7.pkl文件
        if os.path.exists(COOKIE_DIR):
            return
        self.web_driver.get(self.home_page)
        time.sleep(5)
        try:
            log_in_button = self.web_driver.find_element_by_xpath('//*[@id="nav-link-accountList"]')
            self.web_driver.execute_script("arguments[0].click()", log_in_button)
        except:
            print(self.web_driver.page_source)
            print('enter www.amazon.com error!')
            sys.exit()
        # self.auto_login()
        time.sleep(2)
        self.web_driver.find_element_by_id('ap_email').send_keys(self.username)
        self.web_driver.find_element_by_id('ap_email').send_keys(Keys.ENTER)
        time.sleep(2)
        self.web_driver.find_element_by_id('ap_password').send_keys(self.password)
        self.web_driver.find_element_by_id('ap_password').send_keys(Keys.ENTER)
        if self.web_driver.current_url != 'https://www.amazon.com/?ref_=nav_ya_signin&':
            time.sleep(50)
            link = self.get_link()
            print(link)
            if link != '':
                self.approve(link)
            time.sleep(5)
        self.dump_cookie(COOKIE_DIR, self.web_driver)

    def if_login(self, url):
        # 当前网页是不是有登录，有的话就回到homepage,更新cookie,并跳转到当前页面
        self.url = url
        self.web_driver.get(self.url)
        if self.url != self.web_driver.current_url:
            return False
        time.sleep(5)
        source = self.web_driver.page_source
        log_info = re.findall(in_a_re.RE_DIC['log_info'], source)
        if self.web_driver.current_url == self.url and log_info and ('登录' in log_info[0] or 'Sign in' in log_info[0]):
            self.web_driver.get(LOGOUT_URL)
            time.sleep(3)
            self.auto_login()
            self.dump_cookie(COOKIE_DIR, self.web_driver)
            self.web_driver.get(self.url)
            time.sleep(5)
            source = self.web_driver.page_source
            log_info = re.findall(in_a_re.RE_DIC['log_info'], source)
            if log_info and ('登录' in log_info[0] or 'Sign in' in log_info[0]):
                return False
            return True
        elif self.web_driver.current_url == self.url and not log_info:
            return False
        else:
            return True

def addProblem(fileName, inputs):
    if not os.path.exists(fileName):
        file = open(fileName, 'w')
        file.close()
    with open(fileName, "r+", encoding='utf-8') as file:
        lines = file.readlines()
        if len(lines) == 0 or inputs not in lines[-1]:
            file.write(inputs)
            file.write("\n")

def invalidRequest(request):
    if len(request) == 1 and request[0][0] == 'cookie wrong':
        return True
    return False

def isSkillStart(request):
    for req in request:
        if req[1] != "Alexa":
            return True
    return False

def ansAlexa(output, questions):
    if len(questions) == 0:
        question = '.'
    else:
        question = questions[-1]
    Answers = output.getResponses(question)
    for key in Answers:
        return key
    print("Without answer?")
    return ''     
    
def ansSkill(index, output, rounds, request, lastQuestion, typeId, Ans, time_start):
    questions = []
    for req in request:
        if req[1] != 'Alexa':
            questions = nlp_als.splitSentence(req[0])
            break
    if rounds == 0 and index == 0:
        output.addHelpAns(questions)
        return [-1, 'Help', '']
    if rounds == 1 and index == 0:
        return output.getHelpResponse(questions)
    elif time.time() - time_start >= 10 * 60:
        return [1, 'Stop', '']
    else:
        return output.getResponse(questions, lastQuestion, typeId, Ans)

def generateTest(test_dir, res_dir, spider, skill, skillFuncs, driver):
    output = get_ans.getAns(skill.basicComds, skill.sysComds, skillFuncs, driver)
    endWithStop = False
    i = 0
    while i < 3:
        time_start = time.time()
        fileTest = test_dir + re.sub(r'(\W+)', '_', skill.skillName) + str(i) + ".txt"
        log = ''
        Stop = False
        skillStart = False
        crash = False
        questions = []
        lastRequest = []
        lastQuestion = ''
        typeId = -1 #invocation name, help, instructions of help: -1
        Ans = skill.invocation[0]
        rounds = 0

        request = in_a_re.input_and_response(spider, Ans, fileTest)
        if invalidRequest(request) == True:
            i = 0
            continue
        if len(request) == 0:
            continue

        while Stop == False and request[0][1] == 'Alexa' and skillStart == False:
            print(request)
            result = pro_detc.unexpectedSkills(request, skill.skillName, skill.supportRegion) #problem 4: unexpected skills started
            if result[0] == True:
                if result[1] != 'region':
                    if rounds == 0:
                        log += "problem4----------unexpected skills started!\n"
                        addProblem(res_dir + "problem4.txt", skill.skillName + ": " + result[1])
                        skillStart = True
                    else:
                        log += "problem5----------unavailable skill!\n"
                        addProblem(res_dir + "problem5.txt", skill.skillName)
                Stop = True
                break
            
            skillStart = isSkillStart(request)
            if skillStart == True:
                result = pro_detc.privacyLeakage(request)            #problem 2: privacy violation
                if result[0]:
                    log += "problem2----------privacy violation!\n"
                    if len(skill.permission_list) == 0:
                        addProblem(res_dir + "problem2.txt", skill.skillName + ": " + result[1])
                    else:
                        permission_str = ','.join(skill.permission_list)
                        addProblem(res_dir + "problem2.txt", skill.skillName + ": " + result[1] + "(" + permission_str + ")")
                break
            #answer alexa
            for req in request:
                if req[1] == 'Alexa':
                    questions = nlp_als.splitSentence(req[0])
                    break
            Ans = ansAlexa(output, questions)
            if Ans == '':
                Stop = True
                break
            print(Ans)
            rounds = rounds + 1
            request = in_a_re.input_and_response(spider, Ans, fileTest)
            if invalidRequest(request) == True or len(request) == 0:
                Stop = True
                break

        rounds = 0
        while Stop == False and crash == False:
            skillStart = True
            typeId, Ans, lastQuestion = ansSkill(i, output, rounds, request, lastQuestion, typeId, Ans, time_start)
            print(Ans)
            if Ans in pro_detc.StopSign:
                Stop = True
                endWithStop = True
            
            #get new question 
            lastRequest = request
            request = in_a_re.input_and_response(spider, Ans, fileTest)
            if invalidRequest(request) == True:
                break
            print(request)

            #detect problems
            result2 = pro_detc.isUnrespondingVUI(Ans, lastRequest, request, spider, fileTest)     #problem 1: expected exit
            if result2[0]:
                Ans = 'What\'s the time'
                if result2[1] == 1:
                    if Stop == False:
                        log += "problem1----------expected exit!\n"
                        addProblem(res_dir + "problem1.txt", skill.skillName)
                elif result2[1] == 2:
                    if Stop == False:
                        log += "problem1----------expected exit!\n"
                        addProblem(res_dir + "problem1.txt", skill.skillName)
                    else:
                        log += "problem3----------unstoppable skill!\n"
                        addProblem(res_dir + "problem3.txt", skill.skillName)
                break
            if pro_detc.isCrash(lastRequest, request):      #problem 1: expected exit
                log += "problem1----------expected exit!\n"
                addProblem(res_dir + "problem1.txt", skill.skillName)
                crash = True
            result = pro_detc.privacyLeakage(request)            #problem 2: privacy violation
            if result[0]:
                log += "problem2----------privacy violation!\n"
                if len(skill.permission_list) == 0:
                    addProblem(res_dir + "problem2.txt", skill.skillName + ": " + result[1])
                else:
                    permission_str = ','.join(skill.permission_list)
                    addProblem(res_dir + "/problem2.txt", skill.skillName + ": " + result[1] + "(" + permission_str + ")")
            rounds = rounds + 1
            for req in request:
                if req[1] == 'Alexa':
                    Stop = True
                    break
        
        if invalidRequest(request) == True:
            i = 0
            continue
        if pro_detc.isUnstoppable(spider, Ans, fileTest):   #problem 3: unstoppable skill
            log += "problem3----------unstoppable skill!\n"
            addProblem(res_dir + "problem3.txt", skill.skillName)
        if 'problem5' not in log and pro_detc.isUnavailable(skillStart, questions, skill.supportRegion):   #problem 5: unavailable skill
            log += "problem5----------unavailable skill!\n"
            addProblem(res_dir + "problem5.txt", skill.skillName)
        with open(fileTest, "a") as file:
            file.write("\n\nlog:\n")
            file.write(log)
            file.write("\n\ntime:\n")
            file.write(str(time.time() - time_start))
            file.close()
        if 'problem' in log:
            addProblem(res_dir + "problem.txt", skill.skillName)
        if 'problem1' in log or 'problem3' in log:
            spider.web_driver.refresh()
            time.sleep(5)
            deviceLevel_element = spider.web_driver.find_element_by_id('deviceLevel-label')
            spider.web_driver.execute_script("arguments[0].click();", deviceLevel_element)
        if 'problem4' in log or 'problem5' in log:
            return
        i = i + 1
    
    if endWithStop == False:
        fileTest = test_dir + re.sub(r'(\W+)', '_', skill.skillName) + "3.txt"
        log = ''
        Ans = skill.invocation[0]
        time_start = time.time()
        request = in_a_re.input_and_response(spider, Ans, fileTest)
        Ans = 'Stop'
        request = in_a_re.input_and_response(spider, Ans, fileTest)
        if pro_detc.isUnstoppable(spider, Ans, fileTest):   #problem 3: unstoppable skill
            log += "problem3----------unstoppable skill!\n"
            addProblem(res_dir + "problem3.txt", skill.skillName)
        with open(fileTest, "a") as file:
            file.write("\n\nlog:\n")
            file.write(log)
            file.write("\n\ntime:\n")
            file.write(str(time.time() - time_start))
            file.close()
        return



#['[21:50:15:963] - Event: Text.TextMessage', '[21:50:17:684] - Directive: SkillDebugger.CaptureDebuggingInfo', '[21:50:17:752] - Directive: SpeechSynthesizer.Speak', '[21:50:17:755] - Directive: SpeechRecognizer.RequestProcessingCompleted', '[21:50:17:782] - Event: SpeechSynthesizer.SpeechStarted', '[21:50:20:955] - Event: SpeechSynthesizer.SpeechFinished']
