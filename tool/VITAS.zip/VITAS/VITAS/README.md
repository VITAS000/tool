## Vitas
### Requirement
1. We need to login to the amazon developer account to start using the simulator. In most of the cases amazon will send an email to the linked email address for verifications. We use pop to read the emails, so make sure your 110 port is open.
2. Change the ```config.ini``` inside ```config``` directory to add your own account, or you can use the account that we provide.

### How to run Vitas
1. See the ```code``` directory for codes. Use ```python main.py``` to start using Vitas. Vitas will test ```business_and_finance.xlsx```, save the logs in ```../business/``` directory and the problems list in ```../result``` directory by default.

2. Add ```-e + <excel name>``` to change the excel file of skills' document (they are saved in the ```skill_data_set_2021``` directory)

   Add ```-l + <path>``` to set a path to store logs.

   Add ```-o + <path>``` to save the problem list. 

   Use ```-c``` to start using the chatbot, but we recommend not to because the UI of the chatbot is always changing. 

   For example, run ```python main.py -e kids_skill_data_set_1.xlsx -l kids/ -o kids_problem/``` to test ```kids_skill_data_set_1.xlsx``` in the ```skill_data_set_2021``` directory, save the logs in the ```kids``` directory and problems list in the ```kids_problem``` directory.


### Notifications
1. We save the cookies in the cookie directory, but they maybe useless after a period of time. If you discover that Vitas fails to get skills' outputs from the simulator, just delete the cookies and restart, we will generate new cookies for you.
2. Sometimes the verification code is required to login. Vitas provides the interface, so you can input the verification code manually.

