import re
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import Step3_2_GetCommands as get_ans
import Step3_1_InputAndResponse as in_a_re
import Step2_1_GetDocuRetrvComd as nlp_als
import time
StopSign = ['Stop', 'stop', 'Exit', 'exit', 'cancel', 'Cancel', 'quit', 'Quit']
def isCrash(lastRequest, request):
    withAlexa = False
    for ques, speaker in request:
        if speaker == 'Alexa':
            withAlexa = True
            break
    if withAlexa == False:
        return False
    lastQuestions = ''
    for ques, speaker in lastRequest:
        if speaker != 'Alexa':
            lastQuestions = lastQuestions + ques
    goodbye = False
    lastQuestions = lastQuestions.lower()
    goodbye_list = ["see you", "bye", "thank", "account", "app", "App", "tomorrow", "come back"]
    for item in goodbye_list:
        if item in lastQuestions:
            goodbye = True
            break
    if goodbye == False:
        return True
    return False

def isUnrespondingVUI(Ans, lastRequest, request, spider, FileName):
    if len(request) == 0:
        input_string = 'What\'s the time'
        print(input_string)
        requests = in_a_re.input_and_response(spider, input_string, FileName)
        if len(requests) != 0:
            print(requests)
        if len(requests) == 0 or requests[-1][1] != 'Alexa':
            if 'Pause' in Ans:
                input_string = 'Resume'
                print(input_string)
                requests = in_a_re.input_and_response(spider, input_string, FileName)
                if len(requests) != 0 and requests[-1][1] != 'Alexa':
                    return True, 0
                elif len(requests) == 0:
                    return True, 2
                else:
                    return True, 1
            else:
                return True, 2
        else:
            isCra = isCrash(lastRequest, requests)
            if isCra == True:
                return True, 1
            return True, 0
    return False, 0

def privacyLeakage(request):
    privacy = ['zipcode', 'yourname', 'phonenumber', 'creditcard', 'yourgender', 'yourbirthday', 'identitycard', 'youremail', 'address']
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_argument('--headless')
    driver = webdriver.Chrome(options= chrome_options, executable_path="../chrome/chromedriver")
    output = get_ans.getAns({}, {}, [], driver)
    for question, speaker in request:
        if speaker == 'Alexa':
            continue
        protreatedQues = '' #remove character except letters, and convert to lower case
        for letter in question:
            if letter >= 'a' and letter <= 'z':
                protreatedQues = protreatedQues + letter
            elif letter >= 'A' and letter <= 'Z':
                letter = letter.lower()
                protreatedQues = protreatedQues + letter
        for word in privacy:
            if word in protreatedQues:
                #print(word, protreatedQues)
                res = output.getResponses(question)
                if len(res) > 0:
                    driver.close()
                    driver.quit()
                    return True, word
    driver.close()
    driver.quit()
    return False, ''

def isUnstoppable(spider, last_input_string, FileName):
    for sign in StopSign:
        if sign in last_input_string:
            input_string = 'What\'s the time'
            print(input_string)
            requests = in_a_re.input_and_response(spider, input_string, FileName)
            if len(requests) != 0:
                print(requests)
            if len(requests) > 0 and requests[-1][1] != 'Alexa':
                return True
            return False
    return False

def unexpectedSkills(request, skillname, support_region):
    questions = []
    openSkillSentence = ''
    for req in request:
        if req[1] == 'Alexa':
            questions = nlp_als.splitSentence(req[0])
            for ques in questions:
                if 'Ok, Here \'s' in ques or 'Here \'s the skill' in ques:
                    openSkillSentence = ques
                    break
    skillNa = re.findall(r'Ok, Here \'s (.*?)$', openSkillSentence)
    if len(skillNa) == 0:
        skillNa = re.findall(r'Here \'s the skill (.*?)$', openSkillSentence)
    print(skillNa)
    if len(skillNa) == 0:
        return False, ""
    skillname_expect = re.sub(r"[^a-zA-Z0-9]", '', skillname)
    skillname_real = re.sub(r"[^a-zA-Z0-9]", '', skillNa[0])
    if skillname_expect not in skillname_real:
        if support_region == False:
            return True, 'region'
        else:
            unexpected_error = "expect " + skillname + ", but start " + skillNa[0]
            return True, unexpected_error    
    return False, ""

def isUnavailable(skillStart, questions, support_region):
    goodbye_list = ["account", "app", "App"]
    if skillStart == False:
        for question in questions:
            for goodbye in goodbye_list:
                if goodbye in question:
                    return False
        if support_region == False:
            return False
        else:
            return True
    return False