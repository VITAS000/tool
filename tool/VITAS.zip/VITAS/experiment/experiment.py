import spacy
import html
import openpyxl
import argparse
import os
import sys
import io
import re
from openpyxl import Workbook
#sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8')
PATH = os.path.abspath('.')
PATH1 = os.path.join(PATH, 'user')
PATH2 = os.path.join(PATH, 'vitas')
PATH3 = os.path.join(PATH, 'random')
PATH4 = os.path.join(PATH, 'skillExplorer')

def splitSentence(Line):
    Line = toValidStr(Line)
    Line.replace(".&lt;Short audio&gt;.", "<Short audio>.")
    Lines = Line.split("<Short audio>.")
    clauses = []
    for line in Lines:
        nlp = spacy.load("en_core_web_sm")
        doc = nlp(line)
        clause = ""
        inQuotes = False
        tempclauses = []
        for i in range(len(doc)):
            #print(doc[i].text, getTokenPos(doc[i]), getTokenDep(doc[i]))
            if getTokenPos(doc[i]) == "PUNCT":
                if doc[i].text == '.' or doc[i].text == '!' or doc[i].text == '?':
                    if inQuotes == False:
                        if clause != "":
                            tempclauses.append(clause)
                            clause = ""
                    else:
                        clause = clause + doc[i].text
                elif '.' in doc[i].text  or '!' in doc[i].text or '?' in doc[i].text:
                    if '.' in doc[i].text:
                        position = str(doc[i].text).index('.')
                    elif '!' in doc[i].text:
                        position = str(doc[i].text).index('!')
                    else:
                        position = str(doc[i].text).index('?')
                    if clause == "":
                        clause = str(doc[i].text)[: position]
                    else:
                        clause = clause + " " + str(doc[i].text)[: position]
                    tempclauses.append(clause)
                    clause = str(doc[i].text)[position + 1:]
                elif doc[i].text == "\"":
                    if inQuotes == True:
                        inQuotes = False
                    else:
                        inQuotes = True
                    if clause == "":
                        clause = doc[i].text
                    else:
                        clause = clause + " " + doc[i].text
                else:
                    clause = clause + doc[i].text
            elif getTokenPos(doc[i]) != "SPACE":
                if clause != "":
                    clause = clause + " " + doc[i].text
                else:
                    if str(doc[i].text)[0] >= 'a' and str(doc[i].text)[0] <= 'z':
                        if len(tempclauses) > 0:
                            clause = tempclauses.pop()
                            clause = clause + " " + doc[i].text
                        else:
                            clause = clause + doc[i].text
                    else:
                        clause = clause + doc[i].text
        if clause != "":
            tempclauses.append(clause)
        tempclauses.append("<Short audio>")
        clauses.extend(tempclauses)
    if len(clauses) == 0:
        clauses.append(" ")
    else:
        clauses.pop()
    return clauses

def getTokenPos(token):
    if type(token) == spacy.tokens.span.Span:
        return token.root.pos_
    return token.pos_

def toValidStr(string):
    string = html.unescape(string)
    string = string.encode(encoding='utf-8', errors = 'ignore').decode(encoding='utf-8')
    string = string.replace("‘", '\'')
    string = string.replace("’", '\'')
    string = string.replace("”", '\"')
    string = string.replace("“", '\"')
    text = re.compile(u"[\s\w\.'!?,<>]").findall(string)
    string = "".join(text)
    return string

def coverage_user(path, skillname):
    state_space = []
    filename = skillname + '.txt'
    with open(os.path.join(path, filename), 'r', encoding='utf-8') as skillFile:
        line1 = skillFile.readline()
        line = skillFile.readline()
        line = line.replace('\n', '')
        while line and '<--skill exit-->' not in line:
            answers = splitSentence(line)
            if (len(answers) != 1 or answers[0] != " ") and line != '':
                for ans in answers:
                    if 'Ok, Here \'s' in ans or 'Here \'s the skill' in ans:
                        continue
                    else:
                        if ans not in state_space:
                            state_space.append(ans)
            line1 = skillFile.readline()
            if not line1:
                break
            line = skillFile.readline()
            line = line.replace('\n', '')
    return state_space

def coverage_vitas(path, skillname):
    state_space = []
    i = 0
    while True:
        filename = skillname + str(i) + '.txt'
        if not os.path.exists(os.path.join(path, filename)):
            break
        with open(os.path.join(path, filename), 'r', encoding='utf-8') as skillFile:
            line1 = skillFile.readline()
            line = skillFile.readline()
            line = line.replace('\n', '')
            while line and '<--skill exit-->' not in line:
                answers = splitSentence(line)
                if (len(answers) != 1 or answers[0] != " ") and line != '':
                    for ans in answers:
                        if 'Ok, Here \'s' in ans or 'Here \'s the skill' in ans:
                            continue
                        else:
                            if ans not in state_space:
                                state_space.append(ans)
                line1 = skillFile.readline()
                if not line1:
                    break
                line = skillFile.readline()
                line = line.replace('\n', '')
        i = i + 1
    return state_space

def coverage_round_vitas(path, skillname):
    len_state_space = []
    state_space = []
    i = 0
    while True:
        filename = skillname + str(i) + '.txt'
        if not os.path.exists(os.path.join(path, filename)):
            break
        with open(os.path.join(path, filename), 'r', encoding='utf-8') as skillFile:
            line1 = skillFile.readline()
            line = skillFile.readline()
            line = line.replace('\n', '')
            while line and '<--skill exit-->' not in line:
                answers = splitSentence(line)
                if (len(answers) != 1 or answers[0] != " ") and line != '':
                    for ans in answers:
                        if 'Ok, Here \'s' in ans or 'Here \'s the skill' in ans:
                            continue
                        else:
                            if ans not in state_space:
                                state_space.append(ans)
                len_state_space.append(len(state_space))
                line1 = skillFile.readline()
                if not line1:
                    break
                line = skillFile.readline()
                line = line.replace('\n', '')
        i = i + 1
    return len_state_space

def coverage_skillExplorer(path, skillname):
    state_space = []
    skillname = skillname.replace(':', ' ')
    skillname = skillname.replace('\'', ' ')
    DIR = os.path.join(path, skillname)
    index = 0
    k = 2
    if not os.path.exists(os.path.join(DIR, str(index))):
        print(DIR)
        sys.exit()
    while os.path.exists(os.path.join(DIR, str(index))) == True:
        ROUND_DIR = os.path.join(DIR, str(index))
        files = sorted(os.listdir(ROUND_DIR))
        for fileN in files:
            with open(os.path.join(ROUND_DIR, fileN), 'r', encoding='utf-8') as file:
                sign = file.readline()
                content = file.readline()
                while sign:
                    temp_add_space = []
                    if sign[0:2] == 'E:':
                        if '<---same content as before--->' in content:
                            pass
                        elif '<---nothing update--->' in content or '<---response is null--->' in content or '<---no answer--->' in content:
                            pass
                        elif '<---skill closed--->' in content or '<---exit skill--->' in content or '<---network error--->' in content:
                            break
                        else:
                            try:
                                body = re.findall(r'<---(.*?)--->(.*?)$', content)[0][1]
                            except:
                                body = content
                            answers = splitSentence(body)
                            if (len(answers) != 1 or answers[0] != " ") and body != '':
                                for ans in answers:
                                    if 'Ok, Here \'s' in ans or 'Here \'s the skill' in ans:
                                        continue
                                    ans_no_blank = ans.strip()
                                    if ans_no_blank not in state_space and ans_no_blank != '' and ans_no_blank != '.':
                                        state_space.append(ans_no_blank)
                        k = k + 1
                    sign = file.readline()
                    if not sign:
                        break
                    content = file.readline()
        index = index + 1
    return state_space

def coverage_round_skillExplorer(path, skillname):
    len_state_space = []
    state_space = []
    skillname = skillname.replace(':', ' ')
    skillname = skillname.replace('\'', ' ')
    DIR = os.path.join(path, skillname)
    index = 0
    k = 2
    if not os.path.exists(os.path.join(DIR, str(index))):
        print(DIR)
        sys.exit()
    while os.path.exists(os.path.join(DIR, str(index))) == True:
        ROUND_DIR = os.path.join(DIR, str(index))
        files = sorted(os.listdir(ROUND_DIR))
        for fileN in files:
            with open(os.path.join(ROUND_DIR, fileN), 'r', encoding='utf-8') as file:
                sign = file.readline()
                content = file.readline()
                while sign:
                    if sign[0:2] == 'E:':
                        if '<---same content as before--->' in content:
                            pass
                        elif '<---nothing update--->' in content or '<---response is null--->' in content or '<---no answer--->' in content:
                            pass
                        elif '<---skill closed--->' in content or '<---exit skill--->' in content or '<---network error--->' in content:
                            break
                        else:
                            try:
                                body = re.findall(r'<---(.*?)--->(.*?)$', content)[0][1]
                            except:
                                body = content
                            answers = splitSentence(body)
                            if (len(answers) != 1 or answers[0] != " ") and body != '':
                                for ans in answers:
                                    if 'Ok, Here \'s' in ans or 'Here \'s the skill' in ans:
                                        continue
                                    ans_no_blank = ans.strip()
                                    if ans_no_blank not in state_space and ans_no_blank != '' and ans_no_blank != '.':
                                        state_space.append(ans_no_blank)
                        len_state_space.append(len(state_space))
                        k = k + 1
                    sign = file.readline()
                    if not sign:
                        break
                    content = file.readline()
        index = index + 1
    return len_state_space

def get_percentage(len_state_space, min_value):
    for index in range(len(len_state_space)):
        len_state_space[index] = round(len_state_space[index] / min_value, 1)
    return len_state_space

def get_coverage_round(percentage):
    coverage_round = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    last_col = 0
    for j, per in enumerate(percentage):
        col = int(per * 10)
        val = j + 1
        for real_col in range(last_col, min(col, 10)):
            coverage_round[real_col] = val
        if col >= 10:
            break
        last_col = col
    return coverage_round

def get_coverage_vitas_random(EXCEL_NAME):
    book = openpyxl.load_workbook(EXCEL_NAME)
    name = book.sheetnames
    sheet = book[name[0]]
    maxr = sheet.max_row
    index_list = [42]
    #for index in range(2, maxr + 1):
    for index in index_list:
        skillname = sheet.cell(row = index, column = 1).value
        if skillname != None:
            filename = re.sub(r'(\W+)', '_', skillname)
            vitas_state_space = coverage_vitas(PATH2, filename)
            random_state_space = coverage_vitas(PATH3, filename)
            sheet.cell(row = index, column = 2, value = len(vitas_state_space))
            sheet.cell(row = index, column = 3, value = len(random_state_space))
            print(filename, len(vitas_state_space), len(random_state_space))
    book.save(EXCEL_NAME)

def get_coverage_vitas_skillExplorer(EXCEL_NAME):
    book = openpyxl.load_workbook(EXCEL_NAME)
    name = book.sheetnames
    sheet = book[name[0]]
    maxr = sheet.max_row
    for index in range(2, maxr + 1):
        skillname = sheet.cell(row = index, column = 1).value
        if skillname != None:
            filename = re.sub(r'(\W+)', '_', skillname)
            vitas_state_space = coverage_vitas(PATH2, filename)
            ex_state_space = coverage_skillExplorer(PATH4, skillname)
            sheet.cell(row = index, column = 2, value = len(vitas_state_space))
            sheet.cell(row = index, column = 3, value = len(ex_state_space))
            print(filename, len(vitas_state_space), len(ex_state_space))
    book.save(EXCEL_NAME)

def get_coverage_four(EXCEL_NAME):
    docu_list=os.listdir(PATH1)
    book = openpyxl.load_workbook(EXCEL_NAME)
    name = book.sheetnames
    sheet = book[name[0]]
    maxr = sheet.max_row
    for index in range(2, maxr + 1):
        skillname = sheet.cell(row=index, column=1).value
        if skillname != None:
            filename = re.sub(r'(\W+)', '_', skillname)
            user_state_space = coverage_user(PATH1, filename)
            vitas_state_space = coverage_vitas(PATH2, filename)
            random_state_space = coverage_vitas(PATH3, filename)
            ex_state_space = coverage_skillExplorer(PATH4, skillname)
            all_state1 = list(set(vitas_state_space) | set(user_state_space))
            all_state2 = list(set(ex_state_space) | set(random_state_space))
            all_state = list(set(all_state1) | set(all_state2))
            sheet.cell(row=index, column=2, value=len(user_state_space))
            sheet.cell(row=index, column=3, value=len(vitas_state_space))
            sheet.cell(row=index, column=4, value=len(random_state_space))
            sheet.cell(row=index, column=5, value=len(ex_state_space))
            sheet.cell(row=index, column=6, value=len(all_state))
            print(skillname, len(user_state_space), len(vitas_state_space), len(random_state_space), len(ex_state_space), len(all_state))
    book.save(EXCEL_NAME)

def get_coverage_round_vitas_random(EXCEL_NAME):
    book = openpyxl.load_workbook(EXCEL_NAME)
    sheet = book['vitas']
    sheet2 = book['random']
    maxr = sheet.max_row
    for index in range(2, maxr + 1):
        skillname = sheet.cell(row = index, column = 1).value
        if skillname != None:
            print(skillname)
            filename = re.sub(r'(\W+)', '_', skillname)
            vitas_len_state_space = coverage_round_vitas(PATH2, filename)
            random_len_state_space = coverage_round_vitas(PATH3, filename)
            min_state_space = min(vitas_len_state_space[-1], random_len_state_space[-1])
            vitas_percentage = get_percentage(vitas_len_state_space, min_state_space)
            random_percentage = get_percentage(random_len_state_space, min_state_space)
            vitas_round = get_coverage_round(vitas_percentage)
            random_round = get_coverage_round(random_percentage)
            for col in range(len(vitas_round)):
                sheet.cell(row = index, column = col + 2, value = vitas_round[col])
                sheet2.cell(row = index, column = col + 2, value = random_round[col])
    book.save(EXCEL_NAME)

def get_coverage_round_vitas_skillExplorer(EXCEL_NAME):
    book = openpyxl.load_workbook(EXCEL_NAME)
    sheet = book['vitas']
    sheet2 = book['skillExplorer']
    maxr = sheet.max_row
    for index in range(2, maxr + 1):
        skillname = sheet.cell(row = index, column = 1).value
        if skillname != None:
            print(skillname)
            filename = re.sub(r'(\W+)', '_', skillname)
            vitas_len_state_space = coverage_round_vitas(PATH2, filename)
            ex_len_state_space = coverage_round_skillExplorer(PATH4, skillname)
            min_state_space = min(vitas_len_state_space[-1], ex_len_state_space[-1])
            vitas_percentage = get_percentage(vitas_len_state_space, min_state_space)
            ex_percentage = get_percentage(ex_len_state_space, min_state_space)
            vitas_round = get_coverage_round(vitas_percentage)
            ex_round = get_coverage_round(ex_percentage)
            for col in range(len(vitas_round)):
                sheet.cell(row = index, column = col + 2, value = vitas_round[col])
                sheet2.cell(row = index, column = col + 2, value = ex_round[col])
    book.save(EXCEL_NAME)

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument("figure", help="enter the number of figure", action = "store")
    args = parser.parse_args()
    if args.figure == '5':
        get_coverage_vitas_random('fig5_coverage_vitas_vs_random.xlsx')
    elif args.figure == '6':
        get_coverage_vitas_skillExplorer('fig6_coverage_vitas_vs_skillExplorer.xlsx')
    elif args.figure == '7':
        get_coverage_four('fig7_coverage_rate_four.xlsx')
    elif args.figure == '8':
        get_coverage_round_vitas_random('fig8_coverage_round_vitas_vs_random.xlsx')
    elif args.figure == '9':
        get_coverage_round_vitas_skillExplorer('fig9_coverage_round_vitas_vs_skillExplorer.xlsx')
    else:
        print('invalid figure number')